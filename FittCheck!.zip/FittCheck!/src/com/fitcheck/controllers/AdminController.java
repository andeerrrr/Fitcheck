/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fitcheck.controllers;

import com.fitcheck.interfaces.AdminInterface;
import com.fitcheck.models.Admin;
import com.fitcheck.models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Andre Louis Tanalgo
 */
public class AdminController implements AdminInterface{

    @Override
    public boolean Login(Admin admin) {
         try{
            Connection conn = DatabaseConnection.getConnection();
            String sql = "Select * FROM tbl_admin WHERE username = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, admin.getUname());
            statement.setString(2, admin.getPwd());
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()){
                admin.setFname(rs.getString("fullname"));
                return true;
            }
            
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null,
                    "Unable to get list of Students. Please see logs.", 
                    "Save Error", JOptionPane.ERROR_MESSAGE);
            
            System.out.println("Logs: " + e.getMessage());
        }
        
        return false;
    }

    @Override
    public List<Admin> adminList() {
        List <Admin> list = new ArrayList<>();
       try{
           Connection conn  = DatabaseConnection.getConnection();
           String sql = "SELECT * FROM fitcheck_userdatabase ORDER BY username";
           PreparedStatement statement = conn.prepareStatement(sql);
           ResultSet rs = statement.executeQuery();
           
           while (rs.next()){
               User user  = new User();
               
               user.setId(rs.getInt(id));
               user.setUname(rs.getString("username"));
               user.setPwd(rs.getString("password"));
               user.setCardnum(rs.getString("cardnum"));
               user.setFullname(rs.getString("fullname"));
               
               list.add(user);
           }
           
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,
                    "Unable to get list of Students. Please see logs.",
                    "Save Error", JOptionPane.ERROR_MESSAGE);
            
            System.out.println("Logs: " + e.getMessage());
        } 
       return list;
    }
}

    //@Override
    /*public void SaveAdmin(Admin admin) {
        try{
            Connection conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO tbl_admin(username, password, fullname)" +
                    "VALUES (?, ?, ?)";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, admin.getUname());
            statement.setString(2,admin.getPwd());
            statement.setString(3,admin.getFname());
            
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "New admin record was successfully saved.", 
                    "Save", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, 
                "Unable to save admin record. Please see logs.", 
                "Save Error", JOptionPane.ERROR_MESSAGE);
            
            System.out.println("Logs: " + e.getMessage());
        }
    }

    @Override
    public void UpdateAdmin(Admin admin) {
        try{
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE tbl_user SET username = ?, "
                    + "password = ?, " + "fullname = ? WHERE id = ?";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, admin.getUname());
            statement.setString(2,admin.getPwd());
            statement.setString(3,admin.getFname());
            statement.setInt(4, admin.getId());
            
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "New user record was successfully updated.", 
                    "Update", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,
                       "Unable to update the user record. Please see logs.", 
                       "Update Error", JOptionPane.ERROR_MESSAGE);
               
            System.out.println("Logs: " + e.getMessage());
        }
    }

    @Override
    public void DeleteAdmin(String Uname) {
        try{
            Connection conn = DatabaseConnection.getConnection();

            String sql = "DELETE FROM tbl_admin WHERE username = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, Uname);
            
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                    "Admin record was successfully deleted.", 
                    "Delete", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,
                    "Unable to delete Admin record. Please see logs.",
                    "Delete Error.", JOptionPane.ERROR_MESSAGE);
       
            System.out.println("Logs: " + e.getMessage());
        }
    }
}
*/
    
