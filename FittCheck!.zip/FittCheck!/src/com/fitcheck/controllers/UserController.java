/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fitcheck.controllers;

import com.fitcheck.interfaces.UserInterface;
import com.fitcheck.models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

/**
 *
 * @author Andre Louis Tanalgo
 */
public class UserController implements UserInterface{

    @Override
    public void saveUser(User user) {
        try {
        Connection conn = DatabaseConnection.getConnection();
        
        String sql = "INSERT INTO fitcheck_userdatabase(username, password, cardnum, fullname)"+ 
        "VALUES (?, ?, ?, ?)";
                
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1 ,  user.getUname());
            statement.setString(2, user.getPwd());
            statement.setString(3, user.getCardnum());
            statement.setString(4, user.getFullname());
            statement.executeUpdate(); 
            JOptionPane.showMessageDialog(null, "New User record was successfully saved.", 
                    "Save", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "Unable to save User record. Please see logs.", 
                "Save Error", JOptionPane.ERROR_MESSAGE);
            
            System.out.println("Logs: " + e.getMessage());
        }
    }

   /*@Override
    public void updateUser(User user) {
        try{
            Connection conn = DatabaseConnection.getConnection();
            
            String sql = "UPDATE tbl_user SET lastname = ?, "
                    + "firstname = ?, mi = ?, age = ?, gender = ?, "
                    + "dob = ?, address = ? WHERE idnumber = ?";
            PreparedStatement statement = conn.prepareStatement(sql);

            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                    "User record was successfully updated.",
                    "Update", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e){
               JOptionPane.showMessageDialog(null,
                       "Unable to update the User record. Please see logs.", 
                       "Update Error", JOptionPane.ERROR_MESSAGE);
               
               System.out.println("Logs: " + e.getMessage());
        }
    }

    @Override
    public void deleteUser(String idno) {
        try{
            Connection conn = DatabaseConnection.getConnection();
            
            String sql = "DELETE FROM tbl_user WHERE idnumber = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, idno);
            
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, 
                    "User record was successfully deleted.", 
                    "Delete", JOptionPane.INFORMATION_MESSAGE);
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,
                    "Unable to delete User record. Please see logs.",
                    "Delete Error.", JOptionPane.ERROR_MESSAGE);
       
            System.out.println("Logs: " + e.getMessage());
        }
    }
*/
    @Override
    public boolean Login(User user) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM fitcheck_userdatabase WHERE username = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, user.getUname());
            statement.setString(2, user.getPwd());
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                user.setFullname(rs.getString("fullname"));
                return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Unable to get list of Students. Please see logs.", 
                    "Save Error", JOptionPane.ERROR_MESSAGE);
            
            System.out.println("Logs: " + e.getMessage());
        }
        
        return false;
    }
/*
    @Override
    public User getUser(String un) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM tbl_user WHERE fullname = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, un);
            ResultSet rs = statement.executeQuery();
           
            while (rs.next()) {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setUname(rs.getString("username"));
            user.setPwd(rs.getString("password"));
            user.setFullname(rs.getString("fullname"));
            return user;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
            "Unable to get list of Students. Please see logs.",
            "Save Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Logs: " + e.getMessage());
            }
            return null;
    }*/
}
