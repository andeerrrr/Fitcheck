/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.fitcheck.interfaces;

import com.fitcheck.models.Admin;
import java.util.List;



/**
 *
 * @author Andre Louis Tanalgo
 */
public interface AdminInterface {
    public boolean Login(Admin admin);
    //public void SaveAdmin(Admin admin);
    //public void UpdateAdmin(Admin admin);
    //public void DeleteAdmin(String Uname);
    public List<Admin> adminList();
}
