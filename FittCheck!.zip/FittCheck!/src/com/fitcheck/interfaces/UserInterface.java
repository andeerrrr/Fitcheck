/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.fitcheck.interfaces;

import com.fitcheck.models.User;
//import java.util.List;

/**
 *
 * @author Andre Louis Tanalgo
 */
public interface UserInterface {
    
    public boolean Login(User user);
    
    public void saveUser(User user);
    //public void updateUser(User user);
    //public void deleteUser(String idno);
    //public List<User> searchStudent (String searchKey, String searchString);
    //public List<User> studentList();
    //public User getUser(String un);
}
