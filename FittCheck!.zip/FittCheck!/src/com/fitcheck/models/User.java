/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fitcheck.models;

/**
 *
 * @author Andre Louis Tanalgo
 */
public class User {
  private String username;
  private String password;
  private String fullname;
  private String cardnum;
  private int id;
  
  public int getId(){
      return id;
  }

  public void setId(int id){
      this.id = id;
  }
   public String getCardnum(){
       return cardnum;
   }
   
   public void setCardnum(String cardnum){
       this.cardnum = cardnum;
   }
   public String getFullname(){
       return fullname;
   }
       
   public void setFullname(String fullname){
       this.fullname = fullname;
   }
  

    public String getUname(){
        return username;
    }
    
    public void setUname(String username){
        this.username = username;
    }
    
    public String getPwd(){
        return password;
    }
    
    public void setPwd(String password){
        this.password = password;
    }
}
